"""
dataset_loaders.py
===================
Modular adapters that turn a public dataset's on-disk files into the
common (records, is_flow) shape consumed by windowing.py, plus per-record
labels for supervised training.

Adding a new dataset = writing one function that returns a list of dicts
matching feature_extraction's flow-record or packet-record schema, with
a 'label' field attached, and registering it in DATASET_ADAPTERS below.
Nothing else in the pipeline needs to change.

Supported out of the box (files must be downloaded separately by the user
-- see README's Dataset Preparation section; no data is bundled or
fetched automatically, keeping the tool fully offline-installable):
  - cic-ids2017 / cic-ids2018  (flow CSVs, CICFlowMeter format)
  - unsw-nb15                  (flow CSVs)
  - ctu-13                     (flow CSVs, Argus/Netflow-derived)
  - ciciot2023                 (flow CSVs)
  - lanl-auth                  (authentication event CSV — mapped to a
                                 reduced feature set; several
                                 network-flow-only features are marked
                                 unavailable for this dataset)
  - darpa                      (tcpdump-derived; use PCAP path directly
                                 through feature_extraction.extract_from_pcap
                                 rather than this loader)
"""

from __future__ import annotations
import glob
import logging
import os
from typing import List, Dict, Any, Callable

from feature_extraction import extract_from_flow_csv, PacketParseError

logger = logging.getLogger("dataset_loaders")


def _load_all_csvs_in_dir(dir_path: str) -> List[Dict[str, Any]]:
    records: List[Dict[str, Any]] = []
    csv_files = sorted(glob.glob(os.path.join(dir_path, "*.csv")))
    if not csv_files:
        raise PacketParseError(f"No CSV files found in {dir_path}")
    for f in csv_files:
        try:
            recs = extract_from_flow_csv(f)
            records.extend(recs)
            logger.info("Loaded %d records from %s", len(recs), f)
        except PacketParseError as e:
            logger.warning("Skipping %s: %s", f, e)
    return records


def load_cic_ids(dir_path: str) -> List[Dict[str, Any]]:
    """CIC-IDS2017 / CIC-IDS2018 — CICFlowMeter-generated flow CSVs."""
    return _load_all_csvs_in_dir(dir_path)


def load_unsw_nb15(dir_path: str) -> List[Dict[str, Any]]:
    """UNSW-NB15 flow CSVs. Label column may be 'attack_cat' rather than 'Label'."""
    records = _load_all_csvs_in_dir(dir_path)
    return records


def load_ctu13(dir_path: str) -> List[Dict[str, Any]]:
    """CTU-13 botnet capture dataset (Argus-derived flow CSVs)."""
    return _load_all_csvs_in_dir(dir_path)


def load_ciciot2023(dir_path: str) -> List[Dict[str, Any]]:
    """CICIoT2023 — IoT-focused flow CSVs."""
    return _load_all_csvs_in_dir(dir_path)


def load_lanl_auth(dir_path: str) -> List[Dict[str, Any]]:
    """
    LANL Comprehensive/Unified Host and Network Dataset — authentication
    event logs. These are NOT packet/flow captures, so most network-layer
    features (TTL, TCP flags, packet length, port entropy) are
    structurally unavailable and will be reported as such rather than
    fabricated. Only count/frequency/timing-based features derived from
    authentication event cadence are populated.
    """
    logger.warning(
        "LANL auth dataset lacks network packet/flow fields; only "
        "event-frequency-derived features will be populated, all others "
        "default to 0.0 and are flagged unavailable in the feature report."
    )
    return _load_all_csvs_in_dir(dir_path)


DATASET_ADAPTERS: Dict[str, Callable[[str], List[Dict[str, Any]]]] = {
    "cic-ids2017": load_cic_ids,
    "cic-ids2018": load_cic_ids,
    "unsw-nb15": load_unsw_nb15,
    "ctu-13": load_ctu13,
    "ciciot2023": load_ciciot2023,
    "lanl-auth": load_lanl_auth,
}


def load_dataset(name: str, path: str) -> List[Dict[str, Any]]:
    key = name.strip().lower()
    if key not in DATASET_ADAPTERS:
        raise ValueError(
            f"Unknown dataset adapter '{name}'. Available: {list(DATASET_ADAPTERS.keys())}. "
            f"For DARPA/raw PCAP-based datasets, use feature_extraction.extract_from_pcap directly."
        )
    return DATASET_ADAPTERS[key](path)
