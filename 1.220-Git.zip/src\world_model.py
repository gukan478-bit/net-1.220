"""
world_model.py
===============
The temporal "world model": an LSTM that consumes a sequence of past
network states S(t-L+1..t) and predicts:

  1. threat_head    -> P(attack) for each of the next K future steps
                        (sigmoid outputs, one per forecast step)
  2. stage_head     -> attack-stage class distribution at forecast
                        horizon K (softmax over ATTACK_STAGES)
  3. state_head     -> the next state vector S(t+1) (regression) — used
                        for K-step autoregressive rollout: predicted
                        S(t+1) is fed back in as input to predict S(t+2),
                        and so on, conceptually approximating
                        P(S[t+1] | S[t], S[t-1], ..., S[t-L+1]).

CPU-only by design (no CUDA-specific code paths); trains fine on a normal
laptop for window counts in the tens-to-hundreds of thousands.
"""

from __future__ import annotations
from typing import Tuple, Dict

import torch
import torch.nn as nn

from config import ModelConfig, FEATURE_DIM, DEFAULT_MODEL, DEFAULT_SEQUENCE, SequenceConfig


class NetworkWorldModel(nn.Module):
    def __init__(self, feature_dim: int = FEATURE_DIM,
                 model_cfg: ModelConfig = DEFAULT_MODEL,
                 seq_cfg: SequenceConfig = DEFAULT_SEQUENCE):
        super().__init__()
        self.feature_dim = feature_dim
        self.hidden_size = model_cfg.hidden_size
        self.forecast_horizon = seq_cfg.forecast_horizon
        self.num_stage_classes = model_cfg.num_stage_classes

        self.lstm = nn.LSTM(
            input_size=feature_dim,
            hidden_size=model_cfg.hidden_size,
            num_layers=model_cfg.num_lstm_layers,
            dropout=model_cfg.dropout if model_cfg.num_lstm_layers > 1 else 0.0,
            batch_first=True,
        )
        self.dropout = nn.Dropout(model_cfg.dropout)

        # threat probability at each of the K forecast steps
        self.threat_head = nn.Sequential(
            nn.Linear(model_cfg.hidden_size, 64),
            nn.ReLU(),
            nn.Dropout(model_cfg.dropout),
            nn.Linear(64, self.forecast_horizon),
        )

        # attack-stage classification at forecast horizon K
        self.stage_head = nn.Sequential(
            nn.Linear(model_cfg.hidden_size, 64),
            nn.ReLU(),
            nn.Dropout(model_cfg.dropout),
            nn.Linear(64, self.num_stage_classes),
        )

        # next-state regression head (one step) — used autoregressively
        # for K-step state rollout in forecast.py
        self.state_head = nn.Sequential(
            nn.Linear(model_cfg.hidden_size, 128),
            nn.ReLU(),
            nn.Linear(128, feature_dim),
        )

    def encode(self, x_seq: torch.Tensor) -> torch.Tensor:
        """x_seq: (batch, seq_len, feature_dim) -> final hidden repr (batch, hidden)."""
        out, (h_n, c_n) = self.lstm(x_seq)
        last_hidden = h_n[-1]  # top layer's final hidden state
        return self.dropout(last_hidden)

    def forward(self, x_seq: torch.Tensor) -> Dict[str, torch.Tensor]:
        h = self.encode(x_seq)
        threat_logits = self.threat_head(h)          # (batch, K) — raw logits
        stage_logits = self.stage_head(h)             # (batch, num_classes)
        next_state = self.state_head(h)                # (batch, feature_dim) -> S(t+1)
        return {
            "threat_logits": threat_logits,
            "stage_logits": stage_logits,
            "next_state": next_state,
            "hidden": h,
        }

    @torch.no_grad()
    def autoregressive_rollout(self, x_seq: torch.Tensor, steps: int = None
                                ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Perform K-step autoregressive forecasting starting from an observed
        sequence x_seq (batch, seq_len, feature_dim):

          S(t) --model--> predicted S(t+1) --appended & re-encoded--> S(t+2) --> ...

        Returns:
          predicted_states: (batch, steps, feature_dim)
          threat_probs:      (batch, steps)  — one probability per step,
                              taken from the threat_head evaluated at each
                              re-encoded rollout point (not just the final
                              horizon), so the UI can show a full timeline.
          stage_logits_final: (batch, num_classes) — stage distribution at
                              the final rollout step.
        """
        self.eval()
        steps = steps or self.forecast_horizon
        batch, seq_len, feat_dim = x_seq.shape
        current_seq = x_seq.clone()

        predicted_states = []
        threat_probs = []
        stage_logits_final = None

        for step in range(steps):
            out = self.forward(current_seq)
            next_state = out["next_state"]  # (batch, feat_dim)
            # threat prob for THIS step: take the first element of the
            # multi-step threat head, which is trained to represent the
            # immediate-next-window probability given the current context
            step_prob = torch.sigmoid(out["threat_logits"][:, 0])
            threat_probs.append(step_prob)
            predicted_states.append(next_state)
            stage_logits_final = out["stage_logits"]

            # slide window: drop oldest state, append predicted next state
            current_seq = torch.cat(
                [current_seq[:, 1:, :], next_state.unsqueeze(1)], dim=1
            )

        predicted_states = torch.stack(predicted_states, dim=1)  # (batch, steps, feat_dim)
        threat_probs = torch.stack(threat_probs, dim=1)          # (batch, steps)
        return predicted_states, threat_probs, stage_logits_final


def count_parameters(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters() if p.requires_grad)
