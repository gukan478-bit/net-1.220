"""
explain.py
==========
Produces the "Feature -> contribution -> direction" evidence shown for
every alert.

Two attribution backends:
  1. SHAP (KernelExplainer over the model's threat-probability output) —
     used when the `shap` package is installed, since it gives proper
     Shapley-value attributions.
  2. Built-in occlusion/perturbation fallback — always available, no
     extra dependency. Each feature (at each timestep in the sequence) is
     zeroed out (in scaled/standardized space, so "zero" == "at the
     training-set mean") one at a time and the resulting drop/rise in
     predicted threat probability is the feature's attributed
     contribution. This is a standard, well-understood attribution method
     (occlusion sensitivity) and is what runs by default so the tool has
     zero extra offline-install burden.

Both backends report contribution direction (increases/decreases threat
probability) and magnitude, aggregated across the sequence's timesteps
per feature so the UI can show one line per feature rather than per
(feature, timestep) pair.
"""

from __future__ import annotations
from typing import List, Dict, Any, Tuple

import numpy as np
import torch

from config import FEATURE_VECTOR_ORDER
from world_model import NetworkWorldModel


def _predict_threat_prob(model: NetworkWorldModel, x_seq: torch.Tensor) -> float:
    model.eval()
    with torch.no_grad():
        out = model(x_seq.unsqueeze(0) if x_seq.dim() == 2 else x_seq)
        prob = torch.sigmoid(out["threat_logits"][:, 0]).item()
    return prob


def occlusion_attribution(model: NetworkWorldModel, x_seq: np.ndarray, top_k: int = 5
                           ) -> List[Dict[str, Any]]:
    """
    x_seq: (seq_len, feature_dim) — a single SCALED sequence (same scaling
    used at training/inference time; zeroing a feature in this space
    corresponds to setting it to the training-set mean).

    Returns a list of {feature, contribution, direction} dicts, sorted by
    absolute contribution, aggregated (summed) across all timesteps.
    """
    x_tensor = torch.tensor(x_seq, dtype=torch.float32)
    baseline_prob = _predict_threat_prob(model, x_tensor)

    seq_len, feat_dim = x_seq.shape
    contributions = np.zeros(feat_dim, dtype=np.float64)

    for f_idx in range(feat_dim):
        perturbed = x_seq.copy()
        perturbed[:, f_idx] = 0.0  # occlude this feature across all timesteps
        p_tensor = torch.tensor(perturbed, dtype=torch.float32)
        perturbed_prob = _predict_threat_prob(model, p_tensor)
        # positive contribution == removing this feature DECREASED threat
        # probability, i.e. the feature was pushing the prediction UP
        contributions[f_idx] = baseline_prob - perturbed_prob

    order = np.argsort(-np.abs(contributions))[:top_k]
    results = []
    for idx in order:
        contrib = float(contributions[idx])
        results.append({
            "feature": FEATURE_VECTOR_ORDER[idx],
            "contribution": round(contrib, 4),
            "direction": "increases threat probability" if contrib > 0 else "decreases threat probability",
        })
    return results


def shap_attribution(model: NetworkWorldModel, x_seq: np.ndarray,
                      background: np.ndarray, top_k: int = 5) -> List[Dict[str, Any]]:
    """
    SHAP KernelExplainer-based attribution. `background` should be a small
    sample (e.g. 20-50 rows) of representative scaled sequences flattened
    to (N, seq_len*feat_dim), used as the reference distribution.
    Falls back to occlusion_attribution if shap is not installed.
    """
    try:
        import shap
    except ImportError:
        return occlusion_attribution(model, x_seq, top_k=top_k)

    seq_len, feat_dim = x_seq.shape

    def predict_fn(flat_batch: np.ndarray) -> np.ndarray:
        batch = flat_batch.reshape(-1, seq_len, feat_dim)
        t = torch.tensor(batch, dtype=torch.float32)
        model.eval()
        with torch.no_grad():
            out = model(t)
            probs = torch.sigmoid(out["threat_logits"][:, 0]).numpy()
        return probs

    explainer = shap.KernelExplainer(predict_fn, background)
    x_flat = x_seq.reshape(1, -1)
    shap_values = explainer.shap_values(x_flat, nsamples=100)[0]  # (seq_len*feat_dim,)
    shap_matrix = shap_values.reshape(seq_len, feat_dim)

    # aggregate across timesteps per feature (sum of Shapley values)
    per_feature = shap_matrix.sum(axis=0)
    order = np.argsort(-np.abs(per_feature))[:top_k]
    results = []
    for idx in order:
        contrib = float(per_feature[idx])
        results.append({
            "feature": FEATURE_VECTOR_ORDER[idx],
            "contribution": round(contrib, 4),
            "direction": "increases threat probability" if contrib > 0 else "decreases threat probability",
        })
    return results


def explain_alert(model: NetworkWorldModel, x_seq: np.ndarray,
                   background: np.ndarray = None, top_k: int = 5,
                   use_shap: bool = True) -> List[Dict[str, Any]]:
    """Unified entry point used by forecast.py for every displayed alert."""
    if use_shap and background is not None:
        return shap_attribution(model, x_seq, background, top_k=top_k)
    return occlusion_attribution(model, x_seq, top_k=top_k)


def suspicious_flows(raw_window_records: List[Dict[str, Any]], top_k: int = 5) -> List[Dict[str, Any]]:
    """
    Rank flows/hosts within the current window by a simple suspicion
    heuristic (high port fan-out, high SYN-without-ACK ratio, or high
    retransmission rate) and return the top few with a plain-text reason.
    This is a transparent, rule-based ranking (not a black-box score) so
    the reason string is always literally true of the data.
    """
    from collections import defaultdict

    per_src = defaultdict(lambda: {"dst_ports": set(), "syn": 0, "ack": 0, "retrans": 0, "count": 0,
                                    "dst_ip": None, "protocol": None})
    for r in raw_window_records:
        if r.get("_is_flow_record"):
            continue  # heuristic below is packet-native; flow CSVs skip this ranking
        src = r.get("src_ip", "unknown")
        d = per_src[src]
        d["dst_ports"].add(r.get("dst_port", 0))
        d["dst_ip"] = r.get("dst_ip", d["dst_ip"])
        d["protocol"] = r.get("protocol", d["protocol"])
        flags = str(r.get("tcp_flags", ""))
        if "S" in flags:
            d["syn"] += 1
        if "A" in flags:
            d["ack"] += 1
        if r.get("is_retransmission"):
            d["retrans"] += 1
        d["count"] += 1

    scored = []
    for src, d in per_src.items():
        port_fanout = len(d["dst_ports"])
        syn_no_ack_ratio = d["syn"] / max(d["count"], 1)
        retrans_ratio = d["retrans"] / max(d["count"], 1)
        score = port_fanout * 0.5 + syn_no_ack_ratio * 10 + retrans_ratio * 5

        reasons = []
        if port_fanout > 10:
            reasons.append(f"contacted {port_fanout} distinct destination ports")
        if syn_no_ack_ratio > 0.6:
            reasons.append("high SYN-to-ACK imbalance")
        if retrans_ratio > 0.3:
            reasons.append("elevated retransmission rate")
        if not reasons:
            reasons.append("elevated overall connection volume")

        scored.append({
            "source": src,
            "destination": d["dst_ip"] or "-",
            "port_count": port_fanout,
            "protocol": d["protocol"] or "-",
            "reason": ", ".join(reasons),
            "score": round(score, 3),
        })

    scored.sort(key=lambda x: -x["score"])
    return scored[:top_k]
