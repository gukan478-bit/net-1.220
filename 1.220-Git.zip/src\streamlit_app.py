"""
streamlit_app.py
=================
Optional local Streamlit dashboard for the AI Network Attack Forecaster.
This is purely a presentation layer over forecast.run_forecast() — no
different logic, no network calls, no telemetry. Streamlit itself serves
the UI on localhost only; nothing here reaches outside the machine.

Run with:
    streamlit run streamlit_app.py

If streamlit isn't installed, main.py's plain-text CLI dashboard remains
the primary, always-available interface — this file is entirely optional.
"""

from __future__ import annotations
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    import streamlit as st
except ImportError:
    print("Streamlit is not installed. Install it with:\n"
          "    pip install streamlit --break-system-packages\n"
          "Or just use the plain-text dashboard: python3 main.py --pcap <file>")
    sys.exit(1)

from forecast import run_forecast, ForecasterNotTrainedError
from feature_extraction import PacketParseError
from config import PATHS

st.set_page_config(page_title="AI Network Attack Forecaster", layout="wide")

st.title("AI Network Attack Forecaster")
st.caption("Offline temporal-LSTM early-warning system — Wireshark/PCAP and flow-CSV input, "
           "fully local inference, no cloud calls.")

with st.sidebar:
    st.header("Input")
    run_name = st.text_input("Model run name", value="default")
    uploaded = st.file_uploader("Upload a .pcap/.pcapng or flow .csv file",
                                 type=["pcap", "pcapng", "cap", "csv", "tsv"])
    steps_override = st.number_input("Forecast steps (0 = use trained default)",
                                      min_value=0, max_value=50, value=0)
    run_button = st.button("Run Forecast", type="primary")

if run_button:
    if uploaded is None:
        st.warning("Upload a capture or CSV file first.")
    else:
        tmp_dir = os.path.join(PATHS["captures"], "_streamlit_uploads")
        os.makedirs(tmp_dir, exist_ok=True)
        tmp_path = os.path.join(tmp_dir, uploaded.name)
        with open(tmp_path, "wb") as f:
            f.write(uploaded.getbuffer())

        try:
            with st.spinner("Running pipeline (extraction -> windowing -> LSTM forecast)..."):
                result = run_forecast(tmp_path, run_name=run_name,
                                       steps=steps_override or None)
        except ForecasterNotTrainedError as e:
            st.error(str(e))
            st.stop()
        except (PacketParseError, ValueError) as e:
            st.error(str(e))
            st.stop()

        col1, col2, col3, col4 = st.columns(4)
        col1.metric("Current Threat", f"{result['current_threat_probability']*100:.0f}%")
        col2.metric("Risk Level", result["risk_level"])
        col3.metric("Predicted Stage", result["predicted_stage"].replace("_", " ").title())
        col4.metric("Confidence", f"{result['confidence']*100:.0f}%")

        st.subheader("Forecast Timeline")
        timeline = result["forecast_timeline"]
        st.line_chart(
            {"threat_probability": [p["probability"] for p in timeline]},
        )
        st.caption(" | ".join(f"+{p['offset_seconds']}s: {p['probability']*100:.0f}%" for p in timeline))

        st.subheader("Attack Progression")
        st.write(" → ".join(s.replace("_", " ").title() for s in result["attack_progression"]))

        col_a, col_b = st.columns(2)
        with col_a:
            st.subheader("Top Contributing Features")
            for f in result["top_features"]:
                st.write(f"**{f['feature']}**: {f['contribution']:+.3f} ({f['direction']})")

        with col_b:
            st.subheader("Suspicious Traffic")
            if result["suspicious_flows"]:
                st.table(result["suspicious_flows"])
            else:
                st.write("None flagged (or flow-CSV input — per-host ranking needs packet-level data).")

        st.subheader("Recommendation")
        severity = result["risk_level"]
        if severity in ("HIGH", "CRITICAL"):
            st.error(result["recommendation"])
        elif severity == "MEDIUM":
            st.warning(result["recommendation"])
        else:
            st.success(result["recommendation"])

        unavailable = [k for k, v in result.get("feature_availability", {}).items() if not v]
        if unavailable:
            st.info(f"Features unavailable for this input source: {', '.join(unavailable)}")

        with st.expander("Raw JSON output"):
            st.json(result)
else:
    st.info("Upload a capture/CSV file and click **Run Forecast** to begin. "
            "A model must already be trained (see train.py) for the selected run name.")
