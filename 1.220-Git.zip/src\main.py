"""
main.py
=======
The primary CLI entry point: runs the full pipeline on a PCAP or CSV and
renders the plain-text terminal dashboard. Fully offline; no network
access is performed at any point in this script.

Usage:
    python3 main.py --pcap capture.pcap
    python3 main.py --csv traffic.csv
    python3 main.py --pcap capture.pcap --window 10 --steps 5 --run-name default
"""

from __future__ import annotations
import argparse
import logging
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from forecast import run_forecast, ForecasterNotTrainedError
from feature_extraction import PacketParseError

logging.basicConfig(level=logging.WARNING, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")


BANNER_WIDTH = 60


def render_dashboard(result: dict) -> str:
    lines = []
    bar = "=" * BANNER_WIDTH
    lines.append(bar)
    lines.append("       AI NETWORK ATTACK FORECASTER".center(BANNER_WIDTH))
    lines.append(bar)
    lines.append(f"Input: {result['input']}")
    lines.append(f"Window: {result['window_seconds']} sec | Forecast: {result['forecast_steps']} steps")
    lines.append(f"Windows observed: {result['total_windows_observed']}")
    lines.append("")

    prob_pct = result["current_threat_probability"] * 100
    lines.append(f"CURRENT THREAT : {prob_pct:.0f}%")
    lines.append(f"RISK LEVEL     : {result['risk_level']}")
    lines.append(f"PREDICTED STAGE: {result['predicted_stage'].replace('_', ' ')}")
    lines.append(f"CONFIDENCE     : {result['confidence'] * 100:.0f}%")
    lines.append("")

    lines.append("FORECAST")
    for step in result["forecast_timeline"]:
        lines.append(f"+{step['offset_seconds']} sec : {step['probability'] * 100:.0f}%")
    lines.append("")

    lines.append("ATTACK PROGRESSION")
    lines.append(" -> ".join(s.replace("_", " ").title() for s in result["attack_progression"]))
    lines.append("")

    lines.append("TOP FEATURES")
    for i, feat in enumerate(result["top_features"], 1):
        val = feat["contribution"]
        sign = "+" if val >= 0 else "-"
        lines.append(f"{i}. {feat['feature']:<28}{sign}{abs(val):.3f}  ({feat['direction']})")
    lines.append("")

    lines.append("SUSPICIOUS TRAFFIC")
    if result["suspicious_flows"]:
        lines.append(f"{'Source':<16}{'Destination':<16}{'Ports':<8}{'Protocol':<10}Reason")
        for f in result["suspicious_flows"]:
            lines.append(f"{f['source']:<16}{f['destination']:<16}{f['port_count']:<8}"
                         f"{f['protocol']:<10}{f['reason']}")
    else:
        lines.append("(none flagged in current window, or input is flow-CSV based "
                      "— per-host ranking unavailable for aggregated flow records)")
    lines.append("")

    lines.append("RECOMMENDATION")
    lines.append(result["recommendation"])
    lines.append(bar)

    unavailable = [k for k, v in result.get("feature_availability", {}).items() if not v]
    if unavailable:
        lines.append(f"Note: features unavailable for this input source: {', '.join(unavailable)}")
        lines.append(bar)

    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(
        description="AI Network Attack Forecaster — offline early-warning system for Kali Linux."
    )
    src = parser.add_mutually_exclusive_group(required=True)
    src.add_argument("--pcap", help="Path to a .pcap/.pcapng capture file (from Wireshark or tshark).")
    src.add_argument("--csv", help="Path to a flow CSV file (e.g. CIC-IDS2017/2018 format).")
    parser.add_argument("--steps", type=int, default=None, help="Override forecast horizon (K steps).")
    parser.add_argument("--run-name", default="default", help="Trained model artifacts to use.")
    parser.add_argument("--json", action="store_true", help="Print raw JSON instead of the dashboard.")
    args = parser.parse_args()

    input_path = args.pcap or args.csv
    try:
        result = run_forecast(input_path, run_name=args.run_name, steps=args.steps)
    except ForecasterNotTrainedError as e:
        print(f"\n[ERROR] {e}\n", file=sys.stderr)
        sys.exit(1)
    except PacketParseError as e:
        print(f"\n[ERROR] Could not parse input: {e}\n", file=sys.stderr)
        sys.exit(1)
    except ValueError as e:
        print(f"\n[ERROR] {e}\n", file=sys.stderr)
        sys.exit(1)

    if args.json:
        import json
        print(json.dumps(result, indent=2))
    else:
        print(render_dashboard(result))


if __name__ == "__main__":
    main()
