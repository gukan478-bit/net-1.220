"""
feature_extraction.py
======================
Turns raw traffic (a .pcap/.pcapng capture, or a flow CSV such as
CIC-IDS2017/2018) into a flat list of per-packet (or per-flow-record)
dictionaries using the PACKET_FEATURES schema from config.py.

Two backends for PCAP parsing are supported, tried in this order:
  1. scapy       — pure-Python, always available once pip-installed,
                    no external tshark binary required.
  2. pyshark      — wraps tshark; used only if scapy fails to parse a
                    packet (rare, e.g. exotic link-layer types) and
                    tshark is installed on the system.

This module deliberately does NOT aggregate into time windows — that is
windowing.py's job. Keeping extraction and windowing separate means the
same extracted packet stream can be re-windowed at different granularities
(5s/10s/30s) without re-parsing the capture.
"""

from __future__ import annotations
import csv
import logging
import os
from typing import List, Dict, Any, Optional, Iterator

from config import PACKET_FEATURES

logger = logging.getLogger("feature_extraction")


class PacketParseError(Exception):
    """Raised when a capture file cannot be parsed by any available backend."""


# --------------------------------------------------------------------------
# PCAP / PCAPNG extraction
# --------------------------------------------------------------------------
def _flags_to_str(flags) -> str:
    """Normalize scapy TCP flag representations to a short string like 'SA'."""
    try:
        return str(flags)
    except Exception:
        return ""


def extract_from_pcap(pcap_path: str, use_pyshark_fallback: bool = True) -> List[Dict[str, Any]]:
    """
    Parse a .pcap/.pcapng file into a list of per-packet feature dicts.
    Malformed or truncated files raise PacketParseError with a clear message
    rather than crashing the whole pipeline.
    """
    if not os.path.exists(pcap_path):
        raise PacketParseError(f"Capture file not found: {pcap_path}")

    records: List[Dict[str, Any]] = []
    try:
        records = _extract_with_scapy(pcap_path)
    except Exception as e:
        logger.warning("scapy parsing failed (%s); attempting pyshark fallback", e)
        if use_pyshark_fallback:
            try:
                records = _extract_with_pyshark(pcap_path)
            except Exception as e2:
                raise PacketParseError(
                    f"Failed to parse {pcap_path} with both scapy and pyshark: {e2}"
                ) from e2
        else:
            raise PacketParseError(f"Failed to parse {pcap_path} with scapy: {e}") from e

    if not records:
        logger.warning("No packets extracted from %s (empty or all-filtered capture)", pcap_path)
    return records


def _extract_with_scapy(pcap_path: str) -> List[Dict[str, Any]]:
    from scapy.all import PcapReader, IP, IPv6, TCP, UDP, ICMP  # local import: optional dep

    records: List[Dict[str, Any]] = []
    last_seen_by_flow: Dict[tuple, float] = {}
    seen_seq: Dict[tuple, set] = {}

    with PcapReader(pcap_path) as reader:
        for pkt in reader:
            try:
                ts = float(pkt.time)
                ip_layer = None
                if IP in pkt:
                    ip_layer = pkt[IP]
                elif IPv6 in pkt:
                    ip_layer = pkt[IPv6]
                else:
                    # Non-IP (ARP, etc.) — skip; out of scope for this
                    # feature schema, but not an error.
                    continue

                src_ip = ip_layer.src
                dst_ip = ip_layer.dst
                proto = "OTHER"
                src_port = 0
                dst_port = 0
                tcp_flags = ""
                tcp_window = 0
                is_retrans = 0

                ttl = getattr(ip_layer, "ttl", getattr(ip_layer, "hlim", 0)) or 0
                frag = 1 if getattr(ip_layer, "frag", 0) not in (0, None) else 0

                if TCP in pkt:
                    proto = "TCP"
                    tcp = pkt[TCP]
                    src_port, dst_port = int(tcp.sport), int(tcp.dport)
                    tcp_flags = _flags_to_str(tcp.flags)
                    tcp_window = int(getattr(tcp, "window", 0) or 0)

                    flow_key = (src_ip, dst_ip, src_port, dst_port, "TCP")
                    seq = int(getattr(tcp, "seq", 0) or 0)
                    seen_seq.setdefault(flow_key, set())
                    is_retrans = 1 if seq in seen_seq[flow_key] else 0
                    seen_seq[flow_key].add(seq)

                elif UDP in pkt:
                    proto = "UDP"
                    udp = pkt[UDP]
                    src_port, dst_port = int(udp.sport), int(udp.dport)
                elif ICMP in pkt:
                    proto = "ICMP"

                flow_key = (src_ip, dst_ip, src_port, dst_port, proto)
                prev_ts = last_seen_by_flow.get(flow_key)
                iat = (ts - prev_ts) if prev_ts is not None else 0.0
                last_seen_by_flow[flow_key] = ts

                pkt_len = int(len(pkt))
                payload_size = max(0, pkt_len - 40)  # rough header-strip estimate

                records.append({
                    "timestamp": ts,
                    "src_ip": src_ip,
                    "dst_ip": dst_ip,
                    "src_port": src_port,
                    "dst_port": dst_port,
                    "protocol": proto,
                    "tcp_flags": tcp_flags,
                    "ttl": ttl,
                    "tcp_window": tcp_window,
                    "ip_frag": frag,
                    "payload_size": payload_size,
                    "packet_length": pkt_len,
                    "iat": iat,
                    "is_retransmission": is_retrans,
                })
            except Exception as pkt_err:
                # One malformed packet shouldn't kill the whole capture.
                logger.debug("Skipping malformed packet: %s", pkt_err)
                continue

    return records


def _extract_with_pyshark(pcap_path: str) -> List[Dict[str, Any]]:
    import pyshark  # local import: optional dep, requires tshark installed

    records: List[Dict[str, Any]] = []
    last_seen_by_flow: Dict[tuple, float] = {}

    cap = pyshark.FileCapture(pcap_path, keep_packets=False, use_json=True)
    try:
        for pkt in cap:
            try:
                ts = float(pkt.sniff_timestamp)
                if "IP" not in pkt and "IPV6" not in pkt:
                    continue
                ip = pkt.ip if hasattr(pkt, "ip") else pkt.ipv6
                src_ip, dst_ip = ip.src, ip.dst
                ttl = int(getattr(ip, "ttl", 0) or 0)
                frag = 1 if getattr(ip, "flags_mf", "0") == "1" else 0

                proto = "OTHER"
                src_port = dst_port = 0
                tcp_flags = ""
                tcp_window = 0
                is_retrans = 0

                if "TCP" in pkt:
                    proto = "TCP"
                    tcp = pkt.tcp
                    src_port, dst_port = int(tcp.srcport), int(tcp.dstport)
                    tcp_flags = getattr(tcp, "flags", "")
                    tcp_window = int(getattr(tcp, "window_size", 0) or 0)
                    is_retrans = 1 if hasattr(tcp, "analysis_retransmission") else 0
                elif "UDP" in pkt:
                    proto = "UDP"
                    udp = pkt.udp
                    src_port, dst_port = int(udp.srcport), int(udp.dstport)
                elif "ICMP" in pkt:
                    proto = "ICMP"

                flow_key = (src_ip, dst_ip, src_port, dst_port, proto)
                prev_ts = last_seen_by_flow.get(flow_key)
                iat = (ts - prev_ts) if prev_ts is not None else 0.0
                last_seen_by_flow[flow_key] = ts

                pkt_len = int(getattr(pkt, "length", 0) or 0)
                records.append({
                    "timestamp": ts,
                    "src_ip": src_ip,
                    "dst_ip": dst_ip,
                    "src_port": src_port,
                    "dst_port": dst_port,
                    "protocol": proto,
                    "tcp_flags": tcp_flags,
                    "ttl": ttl,
                    "tcp_window": tcp_window,
                    "ip_frag": frag,
                    "payload_size": max(0, pkt_len - 40),
                    "packet_length": pkt_len,
                    "iat": iat,
                    "is_retransmission": is_retrans,
                })
            except Exception as pkt_err:
                logger.debug("Skipping malformed packet (pyshark): %s", pkt_err)
                continue
    finally:
        cap.close()

    return records


# --------------------------------------------------------------------------
# Flow-CSV extraction (CIC-IDS2017/2018-style datasets)
# --------------------------------------------------------------------------
# Column-name aliases across common public datasets. We normalize whatever
# header variant is present to our internal flow-record schema. If a
# required column truly isn't present, that feature stays 0.0 and is
# reported as unavailable — never fabricated.
_CSV_COLUMN_ALIASES: Dict[str, List[str]] = {
    "timestamp": ["Timestamp", "timestamp", "Flow Start", "stime"],
    "src_ip": ["Src IP", "Source IP", "src_ip", "Flow ID", "srcip"],
    "dst_ip": ["Dst IP", "Destination IP", "dst_ip", "dstip"],
    "src_port": ["Src Port", "Source Port", "src_port", "sport"],
    "dst_port": ["Dst Port", "Destination Port", "dst_port", "dsport"],
    "protocol": ["Protocol", "protocol", "proto"],
    "flow_duration": ["Flow Duration", "flow_duration", "dur"],
    "tot_fwd_pkts": ["Tot Fwd Pkts", "Total Fwd Packets", "tot_fwd_pkts", "spkts"],
    "tot_bwd_pkts": ["Tot Bwd Pkts", "Total Backward Packets", "tot_bwd_pkts", "dpkts"],
    "totlen_fwd_pkts": ["TotLen Fwd Pkts", "Total Length of Fwd Packets", "sbytes"],
    "totlen_bwd_pkts": ["TotLen Bwd Pkts", "Total Length of Bwd Packets", "dbytes"],
    "flow_iat_mean": ["Flow IAT Mean", "flow_iat_mean"],
    "flow_iat_std": ["Flow IAT Std", "flow_iat_std"],
    "flow_iat_max": ["Flow IAT Max", "flow_iat_max"],
    "syn_flag_cnt": ["SYN Flag Cnt", "SYN Flag Count"],
    "fin_flag_cnt": ["FIN Flag Cnt", "FIN Flag Count"],
    "rst_flag_cnt": ["RST Flag Cnt", "RST Flag Count"],
    "ack_flag_cnt": ["ACK Flag Cnt", "ACK Flag Count"],
    "psh_flag_cnt": ["PSH Flag Cnt", "PSH Flag Count"],
    "urg_flag_cnt": ["URG Flag Cnt", "URG Flag Count"],
    "label": ["Label", "label", " Label"],
    "attack_category": ["attack_cat", "attack category", "Attack Category"],
}


def _resolve_columns(header: List[str]) -> Dict[str, str]:
    """Map internal field name -> actual CSV column name present in header."""
    header_stripped = {h.strip(): h for h in header}
    resolved = {}
    for internal_name, aliases in _CSV_COLUMN_ALIASES.items():
        for alias in aliases:
            if alias in header_stripped:
                resolved[internal_name] = header_stripped[alias]
                break
    return resolved


def extract_from_flow_csv(csv_path: str) -> List[Dict[str, Any]]:
    """
    Parse a flow-based CSV (e.g. CIC-IDS2017/2018 CSVs) into flow records.
    Returned records use flow-native fields; windowing.py handles both
    packet-native and flow-native records through a common aggregation
    interface (see windowing.aggregate_records).
    """
    if not os.path.exists(csv_path):
        raise PacketParseError(f"CSV file not found: {csv_path}")

    records: List[Dict[str, Any]] = []
    with open(csv_path, "r", encoding="utf-8", errors="replace", newline="") as f:
        reader = csv.reader(f)
        try:
            header = next(reader)
        except StopIteration:
            raise PacketParseError(f"Empty CSV: {csv_path}")

        colmap = _resolve_columns(header)
        if "src_ip" not in colmap and "flow_duration" not in colmap:
            raise PacketParseError(
                f"CSV {csv_path} does not match any known flow-dataset schema "
                f"(no recognizable source-IP or flow-duration column)."
            )
        idx = {k: header.index(v) for k, v in colmap.items()}

        row_num = 1
        malformed = 0
        for row in reader:
            row_num += 1
            try:
                def g(name, default="0"):
                    return row[idx[name]] if name in idx and idx[name] < len(row) else default

                timestamp = _safe_float(g("timestamp", "0"))
                if timestamp <= 0:
                    timestamp = float(row_num)
                label = g("label", "BENIGN").strip()
                attack_category = g("attack_category", label).strip()
                rec = {
                    "timestamp": timestamp,
                    "src_ip": g("src_ip", "0.0.0.0"),
                    "dst_ip": g("dst_ip", "0.0.0.0"),
                    "src_port": int(_safe_float(g("src_port", "0"))),
                    "dst_port": int(_safe_float(g("dst_port", "0"))),
                    "protocol": g("protocol", "OTHER"),
                    "flow_duration": _safe_float(g("flow_duration", "0")),
                    "tot_fwd_pkts": _safe_float(g("tot_fwd_pkts", "0")),
                    "tot_bwd_pkts": _safe_float(g("tot_bwd_pkts", "0")),
                    "totlen_fwd_pkts": _safe_float(g("totlen_fwd_pkts", "0")),
                    "totlen_bwd_pkts": _safe_float(g("totlen_bwd_pkts", "0")),
                    "flow_iat_mean": _safe_float(g("flow_iat_mean", "0")),
                    "flow_iat_std": _safe_float(g("flow_iat_std", "0")),
                    "flow_iat_max": _safe_float(g("flow_iat_max", "0")),
                    "syn_flag_cnt": _safe_float(g("syn_flag_cnt", "0")),
                    "fin_flag_cnt": _safe_float(g("fin_flag_cnt", "0")),
                    "rst_flag_cnt": _safe_float(g("rst_flag_cnt", "0")),
                    "ack_flag_cnt": _safe_float(g("ack_flag_cnt", "0")),
                    "psh_flag_cnt": _safe_float(g("psh_flag_cnt", "0")),
                    "urg_flag_cnt": _safe_float(g("urg_flag_cnt", "0")),
                    "label": label,
                    "attack_cat": attack_category,
                    "_is_flow_record": True,
                }
                records.append(rec)
            except Exception:
                malformed += 1
                continue

    if malformed:
        logger.warning("Skipped %d malformed rows in %s", malformed, csv_path)
    return records


def _safe_float(x: Any) -> float:
    try:
        return float(x)
    except (ValueError, TypeError):
        return 0.0


# --------------------------------------------------------------------------
# Unified entry point
# --------------------------------------------------------------------------
def extract(input_path: str) -> List[Dict[str, Any]]:
    """Dispatch to the correct extractor based on file extension."""
    ext = os.path.splitext(input_path)[1].lower()
    if ext in (".pcap", ".pcapng", ".cap"):
        return extract_from_pcap(input_path)
    elif ext in (".csv", ".tsv"):
        return extract_from_flow_csv(input_path)
    else:
        raise PacketParseError(f"Unsupported input extension: {ext}")
