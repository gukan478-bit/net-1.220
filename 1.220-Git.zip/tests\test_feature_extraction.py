"""
test_feature_extraction.py
===========================
Tests the CSV flow-extraction path (no external tshark/scapy binary
needed for this backend, so it runs anywhere) and malformed-input
handling for both CSV and PCAP paths.
"""

import os
import sys
import tempfile
import textwrap

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import pytest
from feature_extraction import extract_from_flow_csv, extract_from_pcap, PacketParseError


def _write_csv(tmp_path, content: str) -> str:
    path = os.path.join(tmp_path, "flows.csv")
    with open(path, "w") as f:
        f.write(textwrap.dedent(content).strip() + "\n")
    return path


def test_extract_from_flow_csv_basic(tmp_path):
    csv_content = """\
        Src IP,Dst IP,Src Port,Dst Port,Protocol,Flow Duration,Tot Fwd Pkts,Tot Bwd Pkts,SYN Flag Cnt,Label
        10.0.0.1,10.0.0.2,1234,80,TCP,1000000,10,8,1,BENIGN
        10.0.0.3,10.0.0.4,5555,22,TCP,500000,50,0,50,FTP-Patator
    """
    path = _write_csv(tmp_path, csv_content)
    records = extract_from_flow_csv(path)
    assert len(records) == 2
    assert records[0]["label"] == "BENIGN"
    assert records[1]["label"] == "FTP-Patator"
    assert records[1]["syn_flag_cnt"] == 50.0
    assert records[0]["_is_flow_record"] is True


def test_extract_from_flow_csv_missing_file_raises():
    with pytest.raises(PacketParseError):
        extract_from_flow_csv("/nonexistent/path/flows.csv")


def test_extract_from_flow_csv_unrecognized_schema_raises(tmp_path):
    csv_content = """\
        RandomColumnA,RandomColumnB
        1,2
    """
    path = _write_csv(tmp_path, csv_content)
    with pytest.raises(PacketParseError):
        extract_from_flow_csv(path)


def test_extract_from_flow_csv_malformed_rows_are_skipped_not_fatal(tmp_path):
    csv_content = """\
        Src IP,Dst IP,Src Port,Dst Port,Protocol,Label
        10.0.0.1,10.0.0.2,80,443,TCP,BENIGN
        this,row,is,garbage
        10.0.0.5,10.0.0.6,22,22,TCP,BENIGN
    """
    path = _write_csv(tmp_path, csv_content)
    records = extract_from_flow_csv(path)
    # malformed row should be skipped gracefully, not crash extraction
    assert len(records) >= 2


def test_extract_from_pcap_missing_file_raises():
    with pytest.raises(PacketParseError):
        extract_from_pcap("/nonexistent/path/capture.pcap")


def test_extract_from_pcap_empty_file_raises_or_returns_empty(tmp_path):
    bad_path = os.path.join(tmp_path, "not_a_real.pcap")
    with open(bad_path, "wb") as f:
        f.write(b"NOT A VALID PCAP FILE HEADER")
    with pytest.raises(PacketParseError):
        extract_from_pcap(bad_path, use_pyshark_fallback=False)
